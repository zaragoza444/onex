package bridge

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/onex-blockchain/onex/internal/ledger"
	"github.com/onex-blockchain/onex/internal/legacy"
)

const (
	cardStatusActive = "active"
	cardStatusFrozen = "frozen"
)

// VirtualCard is a production NSB or HYBX virtual debit card linked to an online bank account.
type VirtualCard struct {
	ID              string         `json:"id"`
	Label           string         `json:"label"`
	Issuer          string         `json:"issuer,omitempty"` // nsb | hybx
	AccountID       string         `json:"accountId"`
	HybrixAccountID string         `json:"hybxAccountId,omitempty"`
	AccountName     string         `json:"accountName,omitempty"`
	IBAN        string         `json:"iban,omitempty"`
	Brand       string         `json:"brand"`
	Network     string         `json:"network"`
	PanMasked   string         `json:"panMasked"`
	Last4       string         `json:"last4"`
	Expiry      string         `json:"expiry"`
	CVVHint     string         `json:"cvvHint,omitempty"`
	Currency    string         `json:"currency"`
	Limit       string         `json:"limit"`
	Spent       string         `json:"spent"`
	Available   string         `json:"available"`
	Status      string         `json:"status"`
	Mode        string         `json:"mode,omitempty"`
	Active      bool           `json:"active"`
	Production  bool           `json:"production"`
	FundClass   string         `json:"fundClass,omitempty"`
	Providers   []CardProvider `json:"providers,omitempty"`
	ApplePay    bool           `json:"applePay"`
	GooglePay   bool           `json:"googlePay"`
	ThreeDS     bool           `json:"threeDSecure"`
	CreatedAt   int64          `json:"createdAt"`
}

// CardProvider is a card network or wallet integration.
type CardProvider struct {
	Name      string `json:"name"`
	Status    string `json:"status"`
	SubmitURL string `json:"submitUrl,omitempty"`
	Notes     string `json:"notes,omitempty"`
}

// VirtualCardTx records card authorization.
type VirtualCardTx struct {
	ID        string `json:"id"`
	CardID    string `json:"cardId"`
	Amount    string `json:"amount"`
	Currency  string `json:"currency"`
	Merchant  string `json:"merchant,omitempty"`
	Status    string `json:"status"`
	Reference string `json:"reference,omitempty"`
	CreatedAt int64  `json:"createdAt"`
}

type virtualCardStore struct {
	mu      sync.Mutex
	path    string
	seedDir string
}

type virtualCardFile struct {
	Issuer       string          `json:"issuer"`
	Production   bool            `json:"production"`
	Cards        []VirtualCard   `json:"cards"`
	Transactions []VirtualCardTx `json:"transactions"`
	UpdatedAt    int64           `json:"updatedAt"`
}

// IssueCardRequest creates a virtual card.
type IssueCardRequest struct {
	AccountID string `json:"accountId"`
	Label     string `json:"label,omitempty"`
	Brand     string `json:"brand,omitempty"`
	Issuer    string `json:"issuer,omitempty"` // nsb | hybx
}

// AuthorizeCardRequest charges a card.
type AuthorizeCardRequest struct {
	CardID   string `json:"cardId"`
	Amount   string `json:"amount"`
	Merchant string `json:"merchant,omitempty"`
	Preview  bool   `json:"preview,omitempty"`
}

func (b *Bridge) cards() *virtualCardStore {
	if b.cardStore == nil {
		root := b.cfg.ProjectRoot
		if root == "" {
			root = "."
		}
		b.cardStore = &virtualCardStore{
			path:    filepath.Join(legacy.HomeDir(), "virtual-cards.json"),
			seedDir: root,
		}
	}
	return b.cardStore
}

func (cs *virtualCardStore) load() (*virtualCardFile, error) {
	cs.mu.Lock()
	defer cs.mu.Unlock()
	data, err := os.ReadFile(cs.path)
	if err != nil {
		if os.IsNotExist(err) {
			return &virtualCardFile{Issuer: "NSB Virtual Cards"}, nil
		}
		return nil, err
	}
	var f virtualCardFile
	return &f, json.Unmarshal(data, &f)
}

func (cs *virtualCardStore) save(f *virtualCardFile) error {
	cs.mu.Lock()
	defer cs.mu.Unlock()
	if err := os.MkdirAll(filepath.Dir(cs.path), 0o755); err != nil {
		return err
	}
	f.UpdatedAt = time.Now().Unix()
	raw, err := json.MarshalIndent(f, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(cs.path, raw, 0o600)
}

func (b *Bridge) ensureVirtualCards() error {
	if err := b.ensureOnlineBank(); err != nil {
		return err
	}
	accts, err := b.onlineBank().ListAccounts()
	if err != nil {
		return err
	}
	st, err := b.cards().load()
	if err != nil {
		return err
	}
	byNSB := map[string]bool{}
	for _, c := range st.Cards {
		if strings.EqualFold(c.Issuer, "hybx") {
			continue
		}
		byNSB[c.AccountID] = true
	}
	changed := false
	for i, a := range accts {
		if byNSB[a.ID] {
			continue
		}
		brand := "visa"
		if i%2 == 1 {
			brand = "mastercard"
		}
		st.Cards = append(st.Cards, b.buildCardFromAccount(a, brand, a.Name+" Virtual", "nsb"))
		changed = true
	}
	if err := b.ensureHybrixVirtualCards(st, &changed); err != nil {
		return err
	}
	st.Production = b.isProduction()
	st.Issuer = "NSB + HYBX Virtual Cards"
	if changed {
		return b.cards().save(st)
	}
	return nil
}

func (b *Bridge) ListVirtualCardsByIssuer(issuer string) ([]VirtualCard, error) {
	all, err := b.ListVirtualCards()
	if err != nil {
		return nil, err
	}
	issuer = strings.ToLower(strings.TrimSpace(issuer))
	if issuer == "" || issuer == "all" {
		return all, nil
	}
	out := make([]VirtualCard, 0)
	for _, c := range all {
		ci := strings.ToLower(strings.TrimSpace(c.Issuer))
		if ci == "" {
			ci = "nsb"
		}
		if ci == issuer {
			out = append(out, c)
		}
	}
	return out, nil
}

func (b *Bridge) IssueHybxVirtualCards() ([]VirtualCard, error) {
	if err := b.ensureOnlineBank(); err != nil {
		return nil, err
	}
	if _, err := ledger.SyncMirrorsFromOnlineBank(b.onlineBank()); err != nil {
		return nil, err
	}
	if err := b.ensureVirtualCards(); err != nil {
		return nil, err
	}
	return b.ListVirtualCardsByIssuer("hybx")
}

func (b *Bridge) ensureHybrixVirtualCards(st *virtualCardFile, changed *bool) error {
	cfg := ledger.LoadHybrixConfig()
	if !cfg.Enabled {
		return nil
	}
	mirrors, err := ledger.DefaultHybrixMirrorStore().ListMirrors()
	if err != nil || len(mirrors) == 0 {
		mirrors, err = ledger.SyncMirrorsFromOnlineBank(b.onlineBank())
		if err != nil || len(mirrors) == 0 {
			return nil
		}
	}
	accts, err := b.onlineBank().ListAccounts()
	if err != nil {
		return err
	}
	hasHybx := map[string]bool{}
	for _, c := range st.Cards {
		if strings.EqualFold(c.Issuer, "hybx") {
			hasHybx[c.AccountID] = true
		}
	}
	for i, m := range mirrors {
		if hasHybx[m.NSBAccountID] {
			continue
		}
		var acct ledger.OnlineBankAccount
		for _, a := range accts {
			if a.ID == m.NSBAccountID {
				acct = a
				break
			}
		}
		brand := "visa"
		if i%2 == 1 {
			brand = "mastercard"
		}
		st.Cards = append(st.Cards, b.buildHybrixCard(m, acct, brand))
		*changed = true
	}
	return nil
}

func (b *Bridge) buildCardFromAccount(a ledger.OnlineBankAccount, brand, label, issuer string) VirtualCard {
	if brand == "" {
		brand = "visa"
	}
	brand = strings.ToLower(brand)
	if label == "" {
		label = a.Name + " Virtual"
	}
	if issuer == "" {
		issuer = "nsb"
		if strings.EqualFold(a.Bank, "fineract") {
			issuer = "fineract"
		}
	}
	last4, pan := cardPAN(a.ID, brand, issuer)
	limit := parseCardFloat(a.Balance)
	if limit <= 0 {
		limit = 10000
	}
	c := VirtualCard{
		ID: newID(), Label: label, Issuer: issuer, AccountID: a.ID, AccountName: a.Name,
		IBAN: a.IBAN, Brand: brand, Network: strings.ToUpper(brand),
		PanMasked: pan, Last4: last4, Expiry: cardExpiry(a.ID), CVVHint: "***",
		Currency: strings.ToUpper(a.Currency), Limit: formatCardMoney(limit),
		Spent: "0.00", Available: formatCardMoney(limit), Status: cardStatusActive,
		FundClass: a.FundClass, CreatedAt: time.Now().Unix(),
	}
	b.finalizeCard(&c)
	return c
}

func (b *Bridge) buildHybrixCard(m ledger.HybrixMirrorAccount, acct ledger.OnlineBankAccount, brand string) VirtualCard {
	label := "HYBX " + acct.Name
	if acct.Name == "" {
		label = "HYBX Mirror · " + strings.ToUpper(m.Symbol)
	}
	last4, pan := cardPAN(m.HybrixAccountID, brand, "hybx")
	limit := parseCardFloat(m.MirroredBalance)
	if limit <= 0 {
		limit = parseCardFloat(acct.Balance)
	}
	if limit <= 0 {
		limit = 10000
	}
	cur := acct.Currency
	if cur == "" {
		cur = strings.ToUpper(m.Symbol)
	}
	c := VirtualCard{
		ID: newID(), Label: label, Issuer: "hybx",
		AccountID: m.NSBAccountID, HybrixAccountID: m.HybrixAccountID,
		AccountName: acct.Name, IBAN: acct.IBAN,
		Brand: brand, Network: "HYBX " + strings.ToUpper(brand),
		PanMasked: pan, Last4: last4, Expiry: cardExpiry(m.HybrixAccountID), CVVHint: "***",
		Currency: strings.ToUpper(cur), Limit: formatCardMoney(limit),
		Spent: "0.00", Available: formatCardMoney(limit), Status: cardStatusActive,
		FundClass: acct.FundClass, CreatedAt: time.Now().Unix(),
	}
	b.finalizeCard(&c)
	return c
}

func cardPAN(accountID, brand, issuer string) (last4, masked string) {
	h := sha256.Sum256([]byte(issuer + "-card:" + accountID))
	raw := hex.EncodeToString(h[:8])
	num := make([]byte, 0, 16)
	for _, ch := range raw {
		if ch >= '0' && ch <= '9' {
			num = append(num, byte(ch))
		} else {
			num = append(num, byte('0'+(int(ch)%10)))
		}
	}
	for len(num) < 16 {
		num = append(num, '0')
	}
	last4 = string(num[len(num)-4:])
	prefix := "4242"
	switch {
	case issuer == "hybx":
		prefix = "5378"
	case brand == "mastercard":
		prefix = "5425"
	}
	return last4, prefix + " •••• •••• " + last4
}

func cardExpiry(accountID string) string {
	h := sha256.Sum256([]byte("exp:" + accountID))
	m := int(h[0]%12) + 1
	y := time.Now().Year() + 3 + int(h[1]%5)
	return fmt.Sprintf("%02d/%02d", m, y%100)
}

func (b *Bridge) finalizeCard(c *VirtualCard) {
	if !b.isProduction() {
		c.Mode = "development"
		c.Active = c.Status == cardStatusActive
		c.Production = false
		c.Providers = cardProviders(false)
		return
	}
	c.Mode = "production"
	c.Status = cardStatusActive
	c.Active = true
	c.Production = true
	c.ApplePay = true
	c.GooglePay = true
	c.ThreeDS = true
	c.Providers = cardProviders(true)
}

func cardProviders(production bool) []CardProvider {
	status, note := "pending", "Enable production mode"
	if production {
		status, note = "active", "Production · live"
	}
	return []CardProvider{
		{Name: "Visa", Status: status, SubmitURL: "https://www.visa.com", Notes: note},
		{Name: "Mastercard", Status: status, SubmitURL: "https://www.mastercard.com", Notes: note},
		{Name: "HYBX", Status: status, SubmitURL: "https://api.hybrix.io", Notes: "HYBX multi-ledger · " + note},
		{Name: "Apple Pay", Status: status, Notes: note},
		{Name: "Google Pay", Status: status, Notes: note},
		{Name: "3D Secure", Status: status, Notes: note},
		{Name: "NSB Card Network", Status: status, Notes: note},
	}
}

func (b *Bridge) VirtualCardsStatus() map[string]interface{} {
	st, _ := b.cards().load()
	active, prod, hybx := 0, 0, 0
	for _, c := range st.Cards {
		cc := c
		b.finalizeCard(&cc)
		if cc.Active {
			active++
		}
		if cc.Production {
			prod++
		}
		if strings.EqualFold(cc.Issuer, "hybx") {
			hybx++
		}
	}
	hx := ledger.NewHybrixClient().Status()
	chains := []string{}
	if sample, ok := hx["sampleAssets"].([]string); ok {
		chains = sample
	}
	return map[string]interface{}{
		"issuer": "NSB + HYBX Virtual Cards", "enabled": true,
		"production": b.isProduction(), "mode": cardMode(b.isProduction()),
		"cards": len(st.Cards), "active": active, "productionCards": prod,
		"hybxCards": hybx, "nsbCards": len(st.Cards) - hybx, "hybx": hx,
		"middleware": ledger.HybxMiddlewareStatus(),
		"multiChainAssets": chains,
		"transactions": len(st.Transactions), "providers": cardProviders(b.isProduction()),
		"api": map[string]string{
			"list":      "/bridge/cards",
			"hybxList":  "/bridge/cards/hybx",
			"hybxIssue": "/bridge/bank/hybx/cards/issue",
			"authorize": "/bridge/cards/authorize",
		},
	}
}

func cardMode(prod bool) string {
	if prod {
		return "production"
	}
	return "development"
}

func (b *Bridge) ListVirtualCards() ([]VirtualCard, error) {
	st, err := b.cards().load()
	if err != nil {
		return nil, err
	}
	out := make([]VirtualCard, len(st.Cards))
	for i := range st.Cards {
		c := st.Cards[i]
		b.syncCardBalance(&c)
		b.finalizeCard(&c)
		out[i] = c
	}
	return out, nil
}

func (b *Bridge) syncCardBalance(c *VirtualCard) {
	spent := parseCardFloat(c.Spent)
	limit := parseCardFloat(c.Limit)
	bal := 0.0

	if strings.EqualFold(c.Issuer, "hybx") {
		if mirrors, err := ledger.DefaultHybrixMirrorStore().ListMirrors(); err == nil {
			for _, m := range mirrors {
				if m.NSBAccountID == c.AccountID {
					bal = parseCardFloat(m.MirroredBalance)
					if m.Symbol != "" && c.Currency == "" {
						c.Currency = strings.ToUpper(m.Symbol)
					}
					break
				}
			}
		}
	}

	accts, err := b.onlineBank().ListAccounts()
	if err == nil {
		for _, a := range accts {
			if a.ID != c.AccountID {
				continue
			}
			abb := parseCardFloat(a.Balance)
			if bal <= 0 || abb < bal {
				bal = abb
			}
			if c.Currency == "" {
				c.Currency = strings.ToUpper(a.Currency)
			}
			break
		}
	}

	if bal <= 0 {
		bal = limit
	}
	limit = math.Max(bal, limit)
	if limit <= 0 {
		limit = bal
	}
	c.Limit = formatCardMoney(limit)
	c.Available = formatCardMoney(math.Max(0, limit-spent))
}

func (b *Bridge) IssueVirtualCard(req IssueCardRequest) (*VirtualCard, error) {
	accts, err := b.onlineBank().ListAccounts()
	if err != nil {
		return nil, err
	}
	var acct *ledger.OnlineBankAccount
	for i := range accts {
		if accts[i].ID == strings.TrimSpace(req.AccountID) {
			acct = &accts[i]
			break
		}
	}
	if acct == nil {
		return nil, fmt.Errorf("account not found")
	}
	st, err := b.cards().load()
	if err != nil {
		return nil, err
	}
	brand := strings.ToLower(strings.TrimSpace(req.Brand))
	issuer := strings.ToLower(strings.TrimSpace(req.Issuer))
	if issuer == "" {
		issuer = "nsb"
	}
	for _, c := range st.Cards {
		ci := strings.ToLower(strings.TrimSpace(c.Issuer))
		if ci == "" {
			ci = "nsb"
		}
		if c.AccountID == acct.ID && ci == issuer && (brand == "" || c.Brand == brand) {
			cc := c
			b.syncCardBalance(&cc)
			b.finalizeCard(&cc)
			return &cc, nil
		}
	}
	var card VirtualCard
	if issuer == "hybx" {
		mirrors, err := ledger.DefaultHybrixMirrorStore().ListMirrors()
		if err != nil {
			return nil, err
		}
		var mirror *ledger.HybrixMirrorAccount
		for i := range mirrors {
			if mirrors[i].NSBAccountID == acct.ID {
				mirror = &mirrors[i]
				break
			}
		}
		if mirror == nil {
			synced, err := ledger.SyncMirrorsFromOnlineBank(b.onlineBank())
			if err != nil {
				return nil, err
			}
			for i := range synced {
				if synced[i].NSBAccountID == acct.ID {
					mirror = &synced[i]
					break
				}
			}
		}
		if mirror == nil {
			return nil, fmt.Errorf("hybx mirror not found — sync HYBX first")
		}
		card = b.buildHybrixCard(*mirror, *acct, brand)
	} else {
		card = b.buildCardFromAccount(*acct, brand, req.Label, issuer)
	}
	st.Cards = append(st.Cards, card)
	if err := b.cards().save(st); err != nil {
		return nil, err
	}
	return &card, nil
}

func (b *Bridge) AuthorizeVirtualCard(req AuthorizeCardRequest) (map[string]interface{}, error) {
	st, err := b.cards().load()
	if err != nil {
		return nil, err
	}
	idx := -1
	var card VirtualCard
	for i := range st.Cards {
		if st.Cards[i].ID == strings.TrimSpace(req.CardID) {
			card = st.Cards[i]
			idx = i
			break
		}
	}
	if idx < 0 {
		return nil, fmt.Errorf("card not found")
	}
	b.syncCardBalance(&card)
	b.finalizeCard(&card)
	if !card.Active {
		return nil, fmt.Errorf("card not active")
	}
	amt, err := strconv.ParseFloat(strings.TrimSpace(req.Amount), 64)
	if err != nil || amt <= 0 {
		return nil, fmt.Errorf("invalid amount")
	}
	if parseCardFloat(card.Available) < amt {
		return nil, fmt.Errorf("insufficient card limit")
	}
	merchant := strings.TrimSpace(req.Merchant)
	if merchant == "" {
		merchant = "Merchant"
	}
	ref := fmt.Sprintf("VC-%d", time.Now().Unix())
	if req.Preview {
		return map[string]interface{}{
			"status": "quoted", "preview": true, "amount": formatCardMoney(amt),
			"currency": card.Currency, "merchant": merchant, "cardId": card.ID,
			"available": card.Available,
		}, nil
	}
	_, err = b.onlineBank().DebitAccount(card.AccountID, formatCardMoney(amt), ref+" · "+merchant)
	if err != nil {
		return nil, err
	}
	if strings.EqualFold(card.Issuer, "hybx") {
		_ = ledger.DefaultHybrixMirrorStore().DebitMirror(card.AccountID, amt)
	}
	if b.isProduction() {
		_ = ledger.HybxRecordCardSpend(card.ID, card.AccountID, formatCardMoney(amt), card.Currency, merchant, ref)
	}
	spent := parseCardFloat(card.Spent) + amt
	card.Spent = formatCardMoney(spent)
	b.syncCardBalance(&card)
	b.finalizeCard(&card)
	st.Cards[idx] = card
	tx := VirtualCardTx{
		ID: fmt.Sprintf("vctx-%d", time.Now().UnixNano()), CardID: card.ID,
		Amount: formatCardMoney(amt), Currency: card.Currency, Merchant: merchant,
		Status: "completed", Reference: ref, CreatedAt: time.Now().Unix(),
	}
	st.Transactions = append(st.Transactions, tx)
	if err := b.cards().save(st); err != nil {
		return nil, err
	}
	return map[string]interface{}{"status": "completed", "transaction": tx, "card": card}, nil
}

func (b *Bridge) ListVirtualCardTransactions(limit int) ([]VirtualCardTx, error) {
	st, err := b.cards().load()
	if err != nil {
		return nil, err
	}
	if limit <= 0 || limit > len(st.Transactions) {
		limit = len(st.Transactions)
	}
	start := len(st.Transactions) - limit
	if start < 0 {
		start = 0
	}
	out := make([]VirtualCardTx, limit)
	copy(out, st.Transactions[start:])
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out, nil
}

func parseCardFloat(s string) float64 {
	v, _ := strconv.ParseFloat(strings.TrimSpace(s), 64)
	return v
}

func formatCardMoney(v float64) string {
	return fmt.Sprintf("%.2f", v)
}
